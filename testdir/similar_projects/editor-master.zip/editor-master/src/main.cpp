#include <iostream>
#include <string>

#include <boost/program_options.hpp>

#include <kwiwk/version.hpp>
#include <kwiwk/application.hpp>

int main(int argc, char **argv) {
    namespace po = boost::program_options; 
    po::options_description desc; 
    desc.add_options() 
        ("help,h", "Output help") 
        ("version,v", "Output version");

    po::variables_map vm; 
    po::store(po::parse_command_line(argc, argv, desc), vm);
    po::notify(vm);

    if(vm.count("help")) {
        std::cout << desc << "\n";
        return 1;
    }

    if(vm.count("version")) {
        std::cout << KWIWK_MAJOR_VERSION << "." << KWIWK_MINOR_VERSION << "\n";
        return 0;
    }

    std::vector<std::string> files;

    kwk::Application app(files);
    app.run();

    return 0;
}
