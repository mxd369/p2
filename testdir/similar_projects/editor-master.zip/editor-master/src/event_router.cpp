#include <iostream>

#include <ncurses.h>

#include <kwiwk/event_router.hpp>
#include <kwiwk/application.hpp>

namespace kwk {

    Event_router::Event_router(Application * app) {
        this->app = app;
        this->quit = false;
    }

    void Event_router::run() {
        while(! this->quit) {

            int c = wgetch(this->app->window);

            if(c == KEY_LEFT) {
                std::cout << "Got left\n";
            }
            else {
                std::cout << "Got char: " << c << "\n";
            }
        }
    }

}