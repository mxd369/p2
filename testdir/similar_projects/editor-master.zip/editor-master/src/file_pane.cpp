#include <kwiwk/file_pane.hpp>
#include <kwiwk/application.hpp>

namespace kwk {

    File_pane::File_pane(Application * app){
        this->parent_app = app;
    }

    void File_pane::draw(){

    }

}