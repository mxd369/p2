
#include <kwiwk/application.hpp>
#include <ncurses.h>

namespace kwk {

    Application::Application(std::vector<std::string> files): Drawable(), event_router(this) {
        this->init();
    }

    Application::Application(std::string folder, std::vector<std::string> files): Drawable(), event_router(this) {
        this->init();

    }

    void Application::init() {
        initscr();
        noecho();
        this->window = newwin(60, 80, 0, 0);
        keypad(this->window, TRUE);
    }

    // Drawable
    void Application::draw() {
        //TODO: Draw
    }

    void Application::run() {

        event_router.run();

        endwin();
    }

    int Application::term_width() const {
        int row, col;
        getmaxyx(stdscr, row, col);
        return col;
    }

    int Application::term_height() const {
        int row, col;
        getmaxyx(stdscr, row, col);
        return row;
    }

}