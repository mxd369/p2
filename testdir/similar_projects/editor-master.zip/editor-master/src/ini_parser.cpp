#include <fstream>
#include <regex>

#include <kwiwk/ini_parser.hpp>

namespace kwk {
    void Ini_parser::load_file(const std::string &filename) {
        std::ifstream fin(filename);
        if (!fin) {
            throw file_exception(filename);
        }

        std::regex comment_regex("#(.*)");
        std::regex section_regex("\\[(.*)\\]");
        std::regex kv_regex("(.*) = (.*)");

        this->sections.clear();
        this->sections["default"] = Section();

        std::string current_section = "default";

        std::string line;
        while (std::getline(fin, line)) {
            std::smatch m;

            // got comment
            if (std::regex_match(line, m, comment_regex)) {
                continue;
            }

            // got section
            if (std::regex_match(line, m, section_regex)) {
                current_section = m[1];
                // insert section if new
                if (this->sections.find(m[1]) == this->sections.end()) {
                    this->sections[m[1]] = Section();
                }
                continue;
            }

            // got kv pair
            if (std::regex_match(line, m, kv_regex)) {
                this->sections[current_section][m[1]] = m[2];
                continue;
            }
        }
    }

    Ini_parser::Entry_value Ini_parser::get(Section_key section, Entry_key key) {
        if (this->sections.find(section) == this->sections.end()) throw section_exception(section);
        if (this->sections[section].find(key) == this->sections[section].end()) throw key_exception(key);
        return this->sections[section][key];
    }

}
