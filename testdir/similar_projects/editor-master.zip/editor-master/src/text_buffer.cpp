#include <kwiwk/application.hpp>
#include <ncurses.h>
#include <kwiwk/point.hpp>
#include <cassert>
#include <fstream>
#include <kwiwk/text_buffer.hpp>

namespace kwk {

	Text_buffer::Text_buffer(Application *app) {
		assert(app != nullptr);
		this->app = app;
		this->width = app->term_width();
		this->height = app->term_height();
		this->is_draw = true;
		clear();
	}

	Text_buffer::Text_buffer(Application *app, std::string file) {
		assert(app != nullptr);
		this->app = app;
		this->width = app->term_width();
		this->height = app->term_height();
		this->is_draw = true;
		this->load(file);
	}



	void Text_buffer::clear() {
		this->scroll_location = 0;
		this->cursors = { Point{0, 0} };
		this->file_location = "";
		this->lines.clear();
	}

	void Text_buffer::load(std::string location) {
		this->scroll_location = 0;
		this->cursors = { Point{0, 0} };
		this->file_location = location;
		std::ifstream input(location);

		this->lines.clear();
		for (std::string line; std::getline(input, line); ) {
			Line l;
			for(char& c: line) {
				l.push_back(Attr_char{c, 0x0});
			}
			this->lines.push_back(l);
		}

		return;
	}

	void Text_buffer::save_as(std::string location) {
		this->file_location = location;
		std::ofstream output(location);
		for(auto& line: this->lines) {
			for(auto& attr_char: line) {
				output << attr_char.character;
			}
			//TODO: insert EOL
		}
		return;
	}

	void Text_buffer::save() {
		std::ofstream output(this->file_location);
		for (auto &line: this->lines) {
			for (auto &attr_char: line) {
				output << attr_char.character;
			}
			//TODO: insert EOL
		}
		return;
	}

    // Drawable
    void Text_buffer::draw() {

    }

}
