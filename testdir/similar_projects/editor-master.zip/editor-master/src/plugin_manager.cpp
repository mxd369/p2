#include <iostream>

#include <boost/dll/import.hpp>
#include <boost/filesystem/operations.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/function.hpp>

#include <kwiwk/plugin_manager.hpp>
#include <kwiwk/text_buffer.hpp>

namespace dll = boost::dll;
namespace fs = boost::filesystem;

namespace kwk {

    // returns True if successful, false otherwise.
    bool Plugin_manager::load_plugin(std::string path) {
        // get path stuff
        fs::path plugin_path(path);
        typedef boost::shared_ptr<Plugin>(pluginapi_create_t)();
        boost::function<pluginapi_create_t> creator;

        creator = boost::dll::import_alias<pluginapi_create_t>(
                plugin_path,
                "create_plugin",
                dll::load_mode::append_decorations
        );

        boost::shared_ptr<Plugin> plugin = creator();
        auto name = plugin->name();
        plugins[name] = plugin;
        return true;
    }

    // returns True if successful, false otherwise.
    bool Plugin_manager::load_plugin_folder(std::string dir) {
        // get path stuff
        fs::path theDir(dir);
        fs::directory_iterator end_iter;
        // loop over those files and add them via load_plugin()
        if(fs::exists(theDir) && fs::is_directory(theDir)) {
            for(fs::directory_iterator dir_iter(theDir); dir_iter != end_iter; ++dir_iter) {
                load_plugin(dir_iter->path().filename().string()); // Currently does not work, placeholder for other function.
            }

        }
        return true;
    }

    bool Plugin_manager::load_system_plugins() {
        return load_plugin_folder("/etc/kwiwk/plugins/");
    }

    bool Plugin_manager::load_user_plugins() {
        return load_plugin_folder("~/.config/kwiwk/plugins/");
    }

    bool Plugin_manager::load_testing_plugins() {
        return load_plugin_folder("./plugins/");
    }

    // returns the plugin asked for, plugin function is called like
    // get_plugin("PluginName")->FunctionCall();
    // getting plugin by plugin = get_plugin("PluginName"); then calling
    // plugin->FunctionCall();
    // The problem with using this function is that it calls for the text editor to
    // manage going through plugins to get all possible functionality.
    boost::shared_ptr<Plugin> Plugin_manager::get_plugin(std::string name) {
        if (plugins.find(name) == plugins.end()) {
            // do something about it.
            return nullptr;
        } else {
            return plugins[name];
        }
    }

    void run_on_draw(Text_buffer *app) {
        for(std::map<std::string, boost::shared_ptr<Plugin> > plug = plugins.begin();
            plug != plugins.end();
            ++plug) {
            plug->second()->on_draw(app);
        }
    }

    void run_on_update(Text_buffer *app) {
        for(std::map<std::string, boost::shared_ptr<Plugin> > plug = plugins.begin();
            plug != plugins.end();
            ++plug) {
            plug->second()->on_update(app);
        }
    }

    void run_on_load(Text_buffer *app) {
        for(std::map<std::string, boost::shared_ptr<Plugin> > plug = plugins.begin();
            plug != plugins.end();
            ++plug) {
            plug->second()->on_load(app);
        }
    }

}