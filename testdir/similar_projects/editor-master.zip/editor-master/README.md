# kwiwk

Modern terminal text editor for the rest of us  

[![Travis](https://img.shields.io/travis/kwiwk/editor.svg?style=flat-square)](https://travis-ci.org/kwiwk/editor)
[![Code Climate](https://img.shields.io/codeclimate/github/kwiwk/editor.svg?style=flat-square)](https://codeclimate.com/github/kwiwk/editor)
[![C++](https://img.shields.io/badge/C++-14-green.svg?style=flat-square)]()
[![Boost](https://img.shields.io/badge/Boost-1.61-green.svg?style=flat-square)](http://www.boost.org/)
[![GitHub release](https://img.shields.io/github/release/kwiwk/editor.svg?style=flat-square)](https://github.com/kwiwk/editor/releases)
[![Github All Releases](https://img.shields.io/github/downloads/kwiwk/editor/total.svg?style=flat-square)](https://github.com/kwiwk/editor/releases)


### Table of Contents
- [Project Proposal](#project-proposal)
- [Diagrams](#diagrams)
- [Team Members](#team-members)
- [Building](#building)
- [Usage](#usage)
- [Screenshots](#screenshots)
- [Development](#development)
   - [With Linux](#with-linux)
   - [With Vagrant](#with-vagrant)
   - [With Docker](#with-docker)
- [Coding Style] (#coding-style)

### Project Proposal

Kwiwk (kwk for short), will be a terminal text editor developed for Linux systems. It will take advantage of C++14 concepts, Boost C++ library, and ncurses. This editor will take inspirations from popular modern text editors such as Sublime Text, Visiual Sudio Code, 

The proposed system shall:
- load files when supplied via the command line  
- load a folder when supplied via the command line  
- load a blank file when no file/folder supplied  
- display a help page when supplied the `--help` command  
- save a modified file
- save a modified file as a new file
- load a file from a running system
- create a new blank buffer from a running system
- toggle a file pane which contains a listing of the current folder and open files.
- preview a focused file in the file pane
- select a focused file and load as a new tab
- navigate to left tab
- navigate to right tab
- open a file fuzzy finder
- preview a focused fuzzy finder file
- provide a method to load customized functionality at run-time from a predefined directory
- provide a method to reload custom run-time functionality 
- provide a `command palette` which allows users to search for functionality 
- include configured keyboard shortcuts in command palette
- provide language specific configurations
- provide syntax highlighting based on language specific configurations
- use a language specific configuration based on file extension
- toggle an integrated terminal 
- automatically update
- support multple cursor opertations
- support mouse interactions
- move an open editor from the left editor to the right editor
- move an open editor from the right editor to the left editor

### Diagrams

![diagram](https://docs.google.com/drawings/d/13RePjqfU0Mjp4PaqUHYrnGRR2BX_tB8Hif5cUVAFvvU/pub?w=1608&h=1074)

### Team Members
|Role|User|Description|
|---|---|---|
|Team Lead|[Russley Shaw](https://github.com/russleyshaw)|Manages and oversees development team. Creates, distributes, manages issues and velocity. |
|DevOps|[Aaron Joyce](https://github.com/2ajoyce)|Responsible for development workflow and process. Uses Vagrant to make development environment setup easy; Cmake to make reliable compilation process|
|Developer|[Austin La](https://github.com/alzk6)||
|Developer|[Ian Clark](https://github.com/IanTClark)||
|Developer|[Reid Black]()||
|Developer|[Jeremy Daugherty](https://github.com/JeremyDaug)||

### Usage
```
kwk [folder/files]
```

### Screenshots

### Development
Note: the following are assuming you have the repo cloned and are using the root repo folder as your working directory

##### With Linux
```bash
# Create build directory
mkdir build
cd build

# Build the project
cmake ..
make

# Run kwiwk
./kwk
```

##### With Vagrant
1) Install [VirtualBox](https://www.virtualbox.org/wiki/Downloads)  
2) Install [Vagrant](https://www.vagrantup.com/downloads.html)    
3) Provision the VM.
```
vagrant up
```
4) SSH into VM
```
vagrant ssh 
```
5) Build using steps for Development [On Linux](#on-linux)  
6) Type `exit` in the Vagrant session to return back to Windows.  
   


##### With Docker
1) Download Docker - [https://docs.docker.com/engine/installation/](https://docs.docker.com/engine/installation/)  
2) Build container
```
docker build . -t kwiwk
```
3) Run normal
```
docker run kwiwk
```
4) Run test
```
docker run kwiwk ./kwk_test
```

### Coding Style

**File Names**  
```
Header files:
- go in include/{project} folder
- have .hpp extension
Example: include/kwiwk/point2d.hpp

Source files:
- go in src folder
- have .cpp extension
Example: src/point2d.cpp

Header Implementations (such as templates)
- go in include/{project}/impl folder
- have .hpp extension
Example: include/kwiwk/impl/templated_point2d.hpp
```

**Header Gaurds**
```cpp
#ifndef {PROJECT}_{COMPONENT}_HPP
#define {PROJECT}_{COMPONENT}_HPP

#ifndef {PROJECT}_{COMPONENT}_IMPL_HPP
#define {PROJECT}_{COMPONENT}_IMPL_HPP

#ifndef {PROJECT}_{PARENT}_{COMPONENT}_IMPL_HPP
#define {PROJECT}_{PARENT}_{COMPONENT}_IMPL_HPP

...

#endif

// Example: include/kwiwk/point2d.hpp
#ifndef KWIWK_POINT2D_HPP
#define KWIWK_POINT2D_HPP

// Example: include/kwiwk/impl/grid2d.hpp
#ifndef KWIWK_GRID2D_IMPL_HPP
#ifndef KWIWK_GRID2D_IMPL_HPP

// Example: include/kwiwk/tui/radio_button.hpp
#ifndef KWIWK_TUI_RADIO_BUTTON_HPP
#ifndef KWIWK_TUI_RADIO_BUTTON_HPP
```

**Variables**  
```cpp
// Use lower-case underscore
int my_int = 0;

// Use auto when applicable
for(auto& item: items)

// Use lower-case underscore with constants
const double pi = 3.14;
```

**Braces & Indentation**
```cpp
// 4 space indent
// Javascript style braces

for(int i = 0; i < 10; i++) {
    ...
}

do {
    ...
} while(cond);
  

```

**Namespace**  
```cpp
// Prefer explicit namespaces over global "using namespace ..."
// Good:
std::vector v;

// Bad: 
using namespace std;
vector v;

// Local "using namespace ..." statements are acceptable
void my_funct() {
    using namespace std::chrono_literals;
    auto day = 24h;
    ...
}
```

**Classes**  
```cpp
// Use lower-case underscore with first letter capitalized
class Class_name {
    ...
};

// Prefer visibility in order of public, protected, private
class Class_name {
public:
    ...
    
protected:
    ...
    
private:
    ...
    
};

// Public methods should be lower-case underscored
// Private methods should be lower-case underscored, prefixed by underscore
class My_class {
public:
    int get_thing(const char &c) const;
    
private:
    int _get_thing_privately(const char &c) const;
};

```


