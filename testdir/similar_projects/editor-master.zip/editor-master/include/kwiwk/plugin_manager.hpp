#ifndef KWK_PLUGIN_MANAGER_HPP
#define KWK_PLUGIN_MANAGER_HPP

#include <map>
#include <string>
#include <boost/dll/alias.hpp>

#include <kwiwk/plugin.hpp>

#include "text_buffer.hpp"

namespace kwk {

    class Plugin_manager {
    private:
        // <name, plugin>
        std::map<std::string, boost::shared_ptr<Plugin> > plugins;

    public:
        bool load_plugin(std::string path);
        bool load_plugin_folder(std::string dir);
        bool load_system_plugins();
        bool load_user_plugins();
        bool load_testing_plugins();
        // plugin getter
        boost::shared_ptr<Plugin> get_plugin(std::string name);

        // function runners. Get's called by the appropriate class and delegates to plugins.
        void run_on_draw(Text_buffer *app);
        void run_on_update(Text_buffer *app);
        void run_on_load(Text_buffer *app);
    };
}

#endif //KWK_PLUGIN_MANAGER_HPP
