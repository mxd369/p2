#ifndef KWIWK_POINT_HPP
#define KWIWK_POINT_HPP

namespace kwk {

	struct Point {
		int x;
		int y;
	};

}

#endif
