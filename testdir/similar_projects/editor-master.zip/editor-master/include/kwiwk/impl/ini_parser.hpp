#include <kwiwk/ini_parser.hpp>

#ifndef KWIWK_INI_PARSER_IMPL_HPP
#define KWIWK_INI_PARSER_IMPL_HPP

namespace kwk {

    template<typename T>
    inline T Ini_parser::get_as(Section_key section, Entry_key key) {
        auto val = this->get(section, key);
        T tmp;
        std::stringstream ss(val);
        ss >> tmp;
        return tmp;
    }

    template<>
    inline bool Ini_parser::get_as<bool>(Section_key section, Entry_key key) {
        return this->get(section, key) == "true";
    }

}

#endif