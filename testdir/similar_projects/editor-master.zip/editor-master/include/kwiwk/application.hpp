#ifndef KWIWK_APPLICATION_HPP
#define KWIWK_APPLICATION_HPP

#include <string>
#include <vector>

#include <ncurses.h>

#include <kwiwk/event_router.hpp>
#include <kwiwk/drawable.hpp>

namespace kwk {

    class Application: public Drawable {
    public:
        Application(std::vector<std::string> files);
        Application(std::string folder, std::vector<std::string> files);

        void init();

        // Drawable
        void draw();

        void run();
        int term_width() const;
        int term_height() const;

        Event_router event_router;

        WINDOW * window;

    private:
        std::string folder;
    };

}

#endif
