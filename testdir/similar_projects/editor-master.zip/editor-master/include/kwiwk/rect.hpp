#ifndef KWIWK_RECT_HPP
#define KWIWK_RECT_HPP

namespace kwk {
    class Rect {
    public:
        int x, y, w, h;
    };
}

#endif