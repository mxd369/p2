#ifndef KWIWK_INI_PARSER_HPP
#define KWIWK_INI_PARSER_HPP

#include <string>
#include <iostream>
#include <unordered_map>
#include <memory>

#include <kwiwk/easy_exception.hpp>

namespace kwk {
    class Ini_parser {
    public:
        using Entry_key = std::string;
        using Entry_value = std::string;
        using Section_key = std::string;
        using Section = std::unordered_map<Entry_key, Entry_value>;
        using Sections = std::unordered_map<Section_key, Section>;

        void load_file(const std::string &filename);
        Entry_value get(Section_key section, Entry_key key);

        template<typename T>
        inline T get_as(Section_key section, Entry_key key);

        KWIWK_EASY_EXCEPTION(file_exception, "Unable to load file - File: ", std::string);
        KWIWK_EASY_EXCEPTION(section_exception, "Section does not exist - Section: ", std::string);
        KWIWK_EASY_EXCEPTION(key_exception, "Key does not exist in section - Key: ", std::string);

    private:
        Sections sections;
    };
}

#include <kwiwk/impl/ini_parser.hpp>

#endif //PACMANEC_INI_PARSER_HPP