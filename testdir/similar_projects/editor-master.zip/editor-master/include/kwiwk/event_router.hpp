#ifndef KWIWK_EVENT_ROUTER_HPP
#define KWIWK_EVENT_ROUTER_HPP

namespace kwk {

    class Application;

    class Event_router {
    public:
        bool quit;
        Application * app;

        Event_router(Application * app);

        void run();
    };

}

#endif