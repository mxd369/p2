#ifndef KWIWK_PLUGIN_HPP
#define KWIWK_PLUGIN_HPP

#include <string>
#include <set>
#include "text_buffer.hpp"

namespace kwk {

    class Plugin {
    public:
        // Every function should have a name. No exceptions.
        virtual std::string name() const = 0;
        // Every function should have a get_info function.
        // It holds important info to properly manage and run the program
        // Exact return TBD.
        virtual std::string get_info() const = 0;

        // Any function you want to be called place beneath here, make it as
        // restrictive or open as you think is reasonable. Everything you want
        // modified should be passed into the function and/or returned from it.
        virtual void on_draw(Text_buffer *app);
        virtual void on_load(Text_buffer *app);
        virtual void on_update(Text_buffer *app);
    };

}

#endif