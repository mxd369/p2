#ifndef KWIWK_DRAWABLE_HPP
#define KWIWK_DRAWABLE_HPP

#include <kwiwk/rect.hpp>

namespace kwk {

    class Drawable {
    public:
        Drawable() {}

        virtual void draw() = 0;

    protected:
        Rect bounding_box;
    };

}

#endif