#ifndef KWIWK_FILE_PANE_HPP
#define KWIWK_FILE_PANE_HPP

namespace kwk {
    class Application;

    class File_pane {
    public:
        File_pane(Application * app);
        void draw();

    private:
        bool toggle;
        Application * parent_app;
    };

}

#endif
