#ifndef KWIWK_EASY_EXCEPTION_H
#define KWIWK_EASY_EXCEPTION_H

#include <exception>
#include <sstream>

#define KWIWK_EASY_EXCEPTION(NAME, MESSAGE, ARG_TYPE) \
class NAME: public std::exception { \
public: \
    NAME(ARG_TYPE arg) { std::stringstream ss; ss << MESSAGE << arg; my_what = ss.str(); } \
    virtual const char* what() const noexcept { return my_what.c_str(); } \
private: \
    std::string my_what; \
};

#endif