#include <cstdint>

#include <kwiwk/drawable.hpp>
#include <kwiwk/application.hpp>
#include <kwiwk/point.hpp>

namespace kwk {

    struct Attr_char {

        Attr_char(char c, uint8_t attr): character(c), attributes(attr) {}

        const uint8_t DEFAULT   = 0b00000000;
        const uint8_t UNDERLINE = 0b00000001;
        const uint8_t BOLD      = 0b00000010;
       
        // FOREGROUND COLORS
        const uint8_t FGMASK       = 0b00111100;
        const uint8_t FG_BLACK     = 0b00000000;
        const uint8_t FG_RED       = 0b00000100;
        const uint8_t FG_GREEN     = 0b00001000;
        const uint8_t FG_YELLOW    = 0b00001100;
        const uint8_t FG_BLUE      = 0b00010000;
        const uint8_t FG_MAGENTA   = 0b00010100;
        const uint8_t FG_CYAN      = 0b00011000;
        const uint8_t FG_WHITE     = 0b00011100;

        // BACKGROUND COLORS
        const uint8_t BGMASK       = 0b11000000;
        const uint8_t BG_BLACK     = 0b00000000;
        const uint8_t BG_WHITE     = 0b01000000;

        char character;
        uint8_t attributes;
    };

    class Text_buffer: public Drawable {
    public:
        using Line = std::vector<Attr_char>;

        Application * app;

        std::vector<Point> cursors; // cursor location
        std::vector<Line> lines;

        int scroll_location;
        int width; //width of buffer
        int height; // height of buffer
        std::string file_location; // location of file
        bool is_draw; // decide if something will be drawn

        Text_buffer(Application * app);
        Text_buffer(Application * app, std::string file);

        void save();
        void save_as(std::string location);
        void load(std::string location);
        void clear();

        // Drawable
        void draw();
    private:

    };

}
