#include <gtest/gtest.h>

#include <kwiwk/ini_parser.hpp>

TEST(IniParser, Good1) {

    kwk::Ini_parser ini;
    ini.load_file("test/test.ini");

    EXPECT_EQ(ini.get("default", "param one"), "one");
    EXPECT_EQ(ini.get("default", "param two"), "two");

    EXPECT_EQ(ini.get("default", "space param"), "my thing");

    EXPECT_EQ(ini.get_as<int>("default", "param 1"), 1);
    EXPECT_EQ(ini.get_as<int>("default", "param 2"), -2);

    EXPECT_EQ(ini.get_as<bool>("section 1", "param 1"), true);
    EXPECT_EQ(ini.get_as<bool>("section 1", "param 2"), false);

    EXPECT_FLOAT_EQ(ini.get_as<float>("section two", "param 1"), 3.24);
    EXPECT_FLOAT_EQ(ini.get_as<float>("section two", "param 2"), -232.1);
}