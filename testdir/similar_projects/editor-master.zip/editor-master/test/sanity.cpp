#include <gtest/gtest.h>

TEST(Sanity, IsSane) {
    EXPECT_EQ(true, true);
    EXPECT_EQ(false, false);
}

TEST(Sanity, IsNotInsane) {
    EXPECT_NE(true, false);
    EXPECT_NE(false, true);
}