# Comet Editor
Comet Editor is a light, C++ and ncurses-based text editor written completely from scratch. It features a custom string class used to represent lines. 
