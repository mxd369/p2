# simpleText
A simple command line based text editor written in C++ using ncurses

I made this over a couple of evenings to learn how ncurses worked so dont expect wonders


MISSING:

horizontal scrolling

bug fixes

syntax highlighting

fancy bits in status bar

buffer saving
