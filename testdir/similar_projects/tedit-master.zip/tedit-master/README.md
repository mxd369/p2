tedit
=====

NCurses based programmer's text editor.
